Konjunktionen = ["deswegen", "somit", "daher", "also", "dabei", "deshalb", "außerdem", "ferner", "ebenso", "dazu", "zusätzlich", "darunter", "daneben", "dazwischen", "darüber", "dadurch", "demzufolge", "folglich", "infolgedessen", "ergo", "darum", "und", "danach", "davor", "anschließend", "währenddessen", "stattdessen", "dennoch", "ansonsten", "nichtsdestotrotz" ,"nichtsdestoweniger", "überdies", "hinzu", "ergänzend", "hiervon", "hierüber"]


